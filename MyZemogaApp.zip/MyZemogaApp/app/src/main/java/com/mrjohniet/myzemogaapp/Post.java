package com.mrjohniet.myzemogaapp;

public class Post {

    String post;

    Post(String post){

        this.post=post;
    }

    public String getPost() {
        return post;
    }
}
