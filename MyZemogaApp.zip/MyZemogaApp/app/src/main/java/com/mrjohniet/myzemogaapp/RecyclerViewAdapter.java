package com.mrjohniet.myzemogaapp;

import android.content.Context;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolderPost>implements View.OnClickListener {


    ArrayList<Post> postList;
    private View.OnClickListener listener;


    public RecyclerViewAdapter(ArrayList<Post> postList) {

        this.postList = postList;
    }

    //para inflar la vista del layout listado_consulados
    @NonNull
    @Override
    public ViewHolderPost onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.post_item,null,false);

        view.setOnClickListener(this);  //se emplea este método para que el escuchador pueda escuchar el evento de selección

        return new ViewHolderPost(view);
    }

    //Método para actualizar los datos de un ViewHolder existente
    @Override
    public void onBindViewHolder(@NonNull ViewHolderPost viewHolderPost, int pos) {

        viewHolderPost.post.setText(postList.get(pos).getPost());

        if(pos > 6){

            viewHolderPost.blue_indicator.setVisibility(View.INVISIBLE);
        }else {}
    }


    //método que indica el número de elementos del ArrayList
    @Override
    public int getItemCount() {

        return postList.size();
    }

    //se genera el método para escuchar el evento onClick
    public void setOnClickListener(View.OnClickListener listener){
        this.listener=listener;
    }

    //método que se debe desarrollar al implementar View.OnClickListener en la clase
    @Override
    public void onClick(View v) {

        if(listener != null){
            listener.onClick(v);
        }

    }

    //clase interna para definir el ViewHolder que permitirá hacer referencia a los controles del Layout
    public class ViewHolderPost extends RecyclerView.ViewHolder {

        TextView post;
        ImageView blue_indicator;

        //constructor de la clase interna ViewHolderConsulados
        public ViewHolderPost(@NonNull View itemView) {
            super(itemView);

            post = itemView.findViewById(R.id.post);//se encuentra por id el componente del layout listado_consulados
            blue_indicator = itemView.findViewById(R.id.indicator);
        }
    }

    public static int getImageId(Context context, String imageName) {
        return context.getResources().getIdentifier("@drawable/" + imageName, null, context.getPackageName());
    }
}
